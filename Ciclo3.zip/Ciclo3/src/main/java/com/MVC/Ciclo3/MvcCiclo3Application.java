package com.MVC.Ciclo3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcCiclo3Application {

	public static void main(String[] args) {
		SpringApplication.run(MvcCiclo3Application.class, args);
	}

}
